//
//  WPJsonParser.h
//  WPJsonParser
//
//  Created by Vavelin Kévin on 07/01/13.
//  Copyright (c) 2013 Vavelin Kévin. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface WPJsonParser : NSObject

// JSON From URL
@property(nonatomic, retain) NSDictionary *json;

// Array of post from json
@property(nonatomic, retain) NSArray *post;

// Array of category
@property(nonatomic, retain) NSMutableArray *category;

// Property of post
@property(nonatomic, retain) NSDictionary *article;

// Initial URL of wordpress
@property(nonatomic, retain) NSString *url;

// URL Image for thumbnail
@property(nonatomic, retain) NSString *urlImage;

//URL Video Dailymotion
@property(nonatomic, retain) NSString *urlVideo;

// Author of post
@property(nonatomic, retain) NSString *authorPost;


// Title of post
@property(nonatomic, retain) NSString *titlePost;

@property(nonatomic, retain) NSMutableArray *postID;

@property(nonatomic, retain) NSArray *commentArray;

@property(nonatomic, retain) NSString *descriptionArticle;

-(id)initWithCommand:(NSString *)command ofURL:(NSString *)url;

-(NSArray *)getRecentPostOfURL:(NSString *)url withCount:(NSInteger)count;
-(NSMutableArray *)getCategoryOfURL:(NSString *)url;
-(NSDictionary *)getPost:(NSArray *)arrayOfPost atIndex:(NSInteger)index;


-(NSString *)getURLImageThumbnailOfPost:(NSInteger)idArticle;

-(NSString *)getURLPost;
-(NSString *)getPostContent;
-(NSString *)getAuthorOfPost;
-(NSString *)getTitlePost;
-(NSString *)getDescription;

-(NSArray *)getCommentOfPost;

@end
